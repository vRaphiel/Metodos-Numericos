g++ -std=c++11  -I ./eigen main.cpp -o main.exe
